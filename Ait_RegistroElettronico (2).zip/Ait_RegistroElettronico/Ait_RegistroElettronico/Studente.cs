﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Ait_RegistroElettronico
{
    public class Alunno
    {
        private string _Nome;
        private string _cognome;
        private int _Eta;
        private string _MateriaPr;
        private string _classe;



        public string Nome
        {
            get
            {
                return _Nome;
            }

            set
            {
                if (value == null || (value != null && value.Length > 0))
                    _Nome = value;
                else
                    throw new Exception("errore: il nome non puo' essere vuoto");
            }
        }

        public string cognome
        {
            get
            {
                return _cognome;
            }

            set
            {
                if (value == null || (value != null && value.Length > 0))
                    _cognome = value;
                else
                    throw new Exception("errore: il cognome non puo' essere vuoto");
            }
        }

        public int Eta
        {

            get
            {
                return _Eta;
            }

            set
            {
                _Eta = value;
            }
        }


        public string MateriaPr
        {
            get
            {
                return _MateriaPr;
            }

            set
            {
                if (value == null || (value != null && value.Length > 0))
                    _MateriaPr = value;
                else
                    throw new Exception("errore: la materia preferita non puo' essere vuoto");
            }
        }
        public string classe
        {
            get
            {
                return _classe;
            }


            set
            {
                _classe = value;
            }
        }


        public Alunno(string nome, string cognome, int eta, string MateriaPr,string classe)
        {
            this.Nome = nome;
            this.Eta = eta;
            this.MateriaPr = MateriaPr;
            this.cognome = cognome;
            this.classe = classe;
        }
    }

    public class Voti 
    {
        private string _informatica;
        private string _matematica;
        private string _italiano;
        private string _inglese;
        private string _motoria;
        private string _sistemi;
        private string _storia;
        private string _tps;
        private string _telecomunicazioni;


        public string informatica
        {
            get
            {
                return _informatica;
            }
            set
            {
                if (value.Length > 0)
                    _informatica = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string matematica
        {
            get
            {
                return _matematica;
            }
            set
            {
                if (value.Length > 0)
                    _matematica = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string italiano
        {
            get
            {
                return _italiano;
            }
            set
            {
                if (value.Length > 0)
                    _italiano = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string inglese
        {
            get
            {
                return _inglese;
            }
            set
            {
                if (value.Length > 0)
                    _inglese = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string motoria
        {
            get
            {
                return _motoria;
            }
            set
            {
                if (value.Length > 0)
                    _motoria = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string sistemi
        {
            get
            {
                return _sistemi;
            }
            set
            {
                if (value.Length > 0)
                    _sistemi = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string storia
        {
            get
            {
                return _storia;
            }
            set
            {
                if (value.Length > 0)
                    _storia = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string tps
        {
            get
            {
                return _tps;
            }
            set
            {
                if (value.Length > 0)
                    _tps = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public string telecomunicazioni
        {
            get
            {
                return _telecomunicazioni;
            }
            set
            {
                if (value.Length > 0)
                    _telecomunicazioni = value;
                else
                    throw new Exception("errore: non puoi mettere dei voti negativi");
            }
        }

        public Voti(string informatica, string matematica, string italiano, string inglese, string motoria, string sistemi, string storia, string tps, string telecomunicazioni)
        {
            this.informatica = informatica;
            this.matematica = matematica;
            this.italiano = italiano;
            this.inglese = inglese;
            this.motoria = motoria;
            this.sistemi = sistemi;
            this.storia = storia;
            this.tps = tps;
            this.telecomunicazioni = telecomunicazioni;
        }
    }

    public class Assenze
    {
        private string _Data;
        private string _Motivazione;

        public string Data
        {
            get
            {
                return _Data;
            }

            set
            {
                if (value == null || (value != null && value.Length > 0))
                    _Data = value;
                else
                    throw new Exception("errore: la data non puo' essere vuota");
            }
        }

        public string Motivazione
        {
            get
            {
                return _Motivazione;
            }

            set
            {
                if (value == null || (value != null && value.Length > 0))
                    _Motivazione = value;
                else
                    throw new Exception("errore: la motificazione non puo' essere vuota");
            }
        }



        public Assenze(string Data, string Motivazione)
        {
            this.Data = Data;
            this.Motivazione = Motivazione;

        }


    }

    
}
