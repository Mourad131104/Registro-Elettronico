﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace Ait_RegistroElettronico
{
    class Scuola

    {

        public Scuola()
        {
            _Alunni = new List<Alunno>();
            _Voti = new List<Voti>();
            _Assenze = new List<Assenze>();
        }



        //ALUNNO
        private List<Alunno> _Alunni;
        public List<Alunno> Alunni
        {
            get => _Alunni;
        }

        public void aggiungiAlunno(Alunno a)
        {
            _Alunni.Add(a);
        }
        public void eliminaAlunno(int p)
        {
            _Alunni.RemoveAt(p);
        }

        //carica da file json una lista di studenti

        public void CaricaStudenti()
        {


            string fileName = "Lista.json";
            if (File.Exists(fileName))
            {
                string jsonString = File.ReadAllText(fileName);
                _Alunni = JsonSerializer.Deserialize<List<Alunno>>(jsonString);
            }
            else throw new Exception("errore: impossibile caricare i dati da file");


        }

        public void salvaStudenti()
        {
            string fileName = "Lista.json";
            if (File.Exists(fileName))
            {
                string jsonString = JsonSerializer.Serialize(Alunni);
                File.WriteAllText(fileName, jsonString);
            }
            else throw new Exception("errore: impossibile caricare i dati da file");


        }






        //VOTI
        private List<Voti> _Voti;
        public List<Voti> Voti
        {
            get => _Voti;
        }


        public void aggiungiVoto(Voti v)
        {
            _Voti.Add(v);
        }


        public void eliminaVoto(Voti v)
        {
            _Voti.Remove(v);
        }
        //carica da file json una lista di voti

        public void CaricaVoti()
        {


            string fileName = "ListaVoti.json";
            if (File.Exists(fileName))
            {
                string jsonString = File.ReadAllText(fileName);
                _Voti = JsonSerializer.Deserialize<List<Voti>>(jsonString);
            }
            else throw new Exception("errore: impossibile caricare i dati da file");


        }

        public void salvaVoti()
        {
            string fileName = "ListaVoti.json";
            if (File.Exists(fileName))
            {
                string jsonString = JsonSerializer.Serialize(Voti);
                File.WriteAllText(fileName, jsonString);
            }
            else throw new Exception("errore: impossibile caricare i dati da file");


        }







        //ASSENZE
        private List<Assenze> _Assenze;
        public List<Assenze> Assenze
        {
            get => _Assenze;
        }


        public void aggiungiAssenza(Assenze a)
        {
            _Assenze.Add(a);
        }


        public void eliminaAssenza(Assenze a)
        {
            _Assenze.Remove(a);
        }
        //carica da file json una lista di assenze

        public void CaricaAssenze()
        {


            string fileName = "ListaAssenze.json";
            if (File.Exists(fileName))
            {
                string jsonString = File.ReadAllText(fileName);
                _Assenze = JsonSerializer.Deserialize<List<Assenze>>(jsonString);
            }
            else throw new Exception("errore: impossibile caricare i dati da file");


        }

        public void salvaAssenze()
        {
            string fileName = "ListaAssenze.json";
            if (File.Exists(fileName))
            {
                string jsonString = JsonSerializer.Serialize(Assenze);
                File.WriteAllText(fileName, jsonString);
            }
            else throw new Exception("errore: impossibile caricare i dati da file");

        }



    }
}
