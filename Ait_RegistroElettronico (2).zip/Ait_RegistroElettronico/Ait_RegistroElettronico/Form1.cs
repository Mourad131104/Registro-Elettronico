﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bunifu.Utils;


namespace Ait_RegistroElettronico
{
    public partial class Form1 : Form

    {
        Scuola S = new Scuola();
        public Form1()
        {
            InitializeComponent();
            string message = "BENVENUTO NEL REGISTRO ELETTRONICO DI AIT MOURAD";
            string title = "REGISTRO ELETTRONICO";
            MessageBox.Show(message, title);

        }




        private void Instagram_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/mourad__13/");
        }

        private void Facebook_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/profile.php?id=100005241885229");
        }


        //
        //
        //


        private void button1_Click(object sender, EventArgs e)  //colore button
        {

            if (colorDialog2.ShowDialog() == DialogResult.OK)
            {
                Instagram.BackColor = colorDialog2.Color;
                Facebook.BackColor = colorDialog2.Color;
                ButtonColButt.BackColor = colorDialog2.Color;
                ButtonCambSfo.BackColor = colorDialog2.Color;
                ButtonImagineSf.BackColor = colorDialog2.Color;
                ButtonEliminaRow.BackColor = colorDialog2.Color;
                ButtonAggiorna.BackColor = colorDialog2.Color;
                buttonAggVoti2.BackColor = colorDialog2.Color;
                ButtonAssenze.BackColor = colorDialog2.Color;
                buttonCaricaVoti.BackColor = colorDialog2.Color;
                buttonSalvaVoti.BackColor = colorDialog2.Color;
                buttonSvuota.BackColor = colorDialog2.Color;
                buttonCarica.BackColor = colorDialog2.Color;
                buttonScarica.BackColor = colorDialog2.Color;
                ButtonEliminaRow.BackColor = colorDialog2.Color;
                buttonCaricaAssenze.BackColor = colorDialog2.Color;
                buttonSalvaAssenze.BackColor = colorDialog2.Color;
                buttonEliminaRigaAss.BackColor = colorDialog2.Color;
                buttonElimina.BackColor = colorDialog2.Color;

            }
        }

        private void button2_Click(object sender, EventArgs e)  //colore sfondo
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                tabPage1.BackColor = colorDialog1.Color;
                tabPage0.BackColor = colorDialog1.Color;
                tabPage5.BackColor = colorDialog1.Color;
                tabPage4.BackColor = colorDialog1.Color;
                tabPage2.BackColor = colorDialog1.Color;
            }
        }

        private void ButtonImagineSf_Click(object sender, EventArgs e)
        {
            OpenFileDialog opnfd = new OpenFileDialog();
            opnfd.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
            if (opnfd.ShowDialog() == DialogResult.OK)
            {
                tabPage1.BackgroundImage = new Bitmap(opnfd.FileName);
                tabPage0.BackgroundImage = new Bitmap(opnfd.FileName);
                tabPage5.BackgroundImage = new Bitmap(opnfd.FileName);
                tabPage4.BackgroundImage = new Bitmap(opnfd.FileName);
                tabPage2.BackgroundImage = new Bitmap(opnfd.FileName);

            }
        }

        private void ButtonAggiorna_Click(object sender, EventArgs e)
        {
            if (textBoxNome.Text != null && textBoxEta.Text != null && textBoxPref.Text != null && textBoxCog.Text != null)
            {
                Ait_RegistroElettronico.Alunno s1;
                String Nome = Convert.ToString(textBoxNome.Text);
                int eta = Convert.ToInt32(textBoxEta.Text);
                string MateriaPr = Convert.ToString(textBoxPref.Text);
                string cognome = Convert.ToString(textBoxCog.Text);
                string classe = Convert.ToString(textBoxClasse.Text);
                s1 = new Alunno(Nome, cognome, eta, MateriaPr, classe);
                S.aggiungiAlunno(s1);
                dataGridViewStudente.Rows.Add(Nome, cognome, eta, MateriaPr, classe);
                comboBoxElimina.Items.Add(s1.Nome+ " "+ s1.cognome);
                comboBoxModifica.Items.Add(s1.Nome + " " + s1.cognome);

            }

            else
            {
                string box = "non hai compilato tutti i campi, completati e poi clicca  AGGIORNA  ";
                MessageBox.Show(box);
            }

        }

        private void buttonEliminaCelle_Click(object sender, EventArgs e)
        {
            textBoxNome.Text = "";
            textBoxEta.Text = "";
            textBoxPref.Text = "";
            textBoxCog.Text = "";
            textBoxClasse.Text = "";
        }

        private void textBoxEta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }


        private void ButtonEliminaRow_Click_1(object sender, EventArgs e)
        {
            if (this.dataGridViewStudente.SelectedRows.Count > 0)
            {
                dataGridViewStudente.Rows.RemoveAt(this.dataGridViewStudente.SelectedRows[0].Index); //source:https://tinyurl.com/hk4nkr9w
            }
        }

        private void buttonAggVoti2_Click(object sender, EventArgs e)
        {
            Ait_RegistroElettronico.Voti v1;


            string informatica = comboBoxInfo.Text;
            string matematica = comboBoxMate.Text;
            string italiano = comboBoxIta.Text;
            string inglese = comboBoxIng.Text;
            string motoria = comboBoxMot.Text;
            string sistemi = comboBoxSist.Text;
            string storia = comboBoxSto.Text;
            string tps = comboBoxTps.Text;
            string telecomunicazioni = comboBoxTel.Text;
            v1 = new Voti(informatica, matematica, italiano, inglese, motoria, sistemi, storia, tps, telecomunicazioni);
            S.aggiungiVoto(v1);
            dataGridViewPagella.Rows.Add("informatica", informatica);
            dataGridViewPagella.Rows.Add("matematica", matematica);
            dataGridViewPagella.Rows.Add("italiano", italiano);
            dataGridViewPagella.Rows.Add("inglese", inglese);
            dataGridViewPagella.Rows.Add("motoria", motoria);
            dataGridViewPagella.Rows.Add("sistemi", sistemi);
            dataGridViewPagella.Rows.Add("storia", storia);
            dataGridViewPagella.Rows.Add("tps", tps);
            dataGridViewPagella.Rows.Add("telecomunicazioni", telecomunicazioni);

            //media
            double media;
            double somma = 0;            //fonte: csharp-console-examples.com/loop/for-loop/calculate-the-average-of-all-items-in-listbox/
            int lstCount = dataGridViewPagella.RowCount;
            double informatica2 = Convert.ToDouble(comboBoxInfo.Text);
            double matematica2 = Convert.ToDouble(comboBoxMate.Text);
            double italiano2 = Convert.ToDouble(comboBoxIta.Text);
            double inglese2 = Convert.ToDouble(comboBoxIng.Text);
            double motoria2 = Convert.ToDouble(comboBoxMot.Text);
            double sistemi2 = Convert.ToDouble(comboBoxSist.Text);
            double storia2 = Convert.ToDouble(comboBoxSto.Text);
            double tps2 = Convert.ToDouble(comboBoxTps.Text);
            double telecomunicazioni2 = Convert.ToDouble(comboBoxTel.Text);

            somma += Convert.ToDouble(informatica2 + matematica2 + italiano2 + inglese2 + motoria2 + sistemi2 + storia2 + tps2 + telecomunicazioni2);
            media = somma / lstCount;
            labelMediaGen.Text = "Media : " + Math.Round(media, 2);

            //chart
            this.chart1.Series["Voti"].Points.AddXY("informatica", informatica);
            this.chart1.Series["Voti"].Points.AddXY("matematica", matematica);
            this.chart1.Series["Voti"].Points.AddXY("italiano", italiano);
            this.chart1.Series["Voti"].Points.AddXY("inglese", inglese);
            this.chart1.Series["Voti"].Points.AddXY("motoria", motoria);
            this.chart1.Series["Voti"].Points.AddXY("sistemi", sistemi);
            this.chart1.Series["Voti"].Points.AddXY("storia", storia);
            this.chart1.Series["Voti"].Points.AddXY("tps", tps);
            this.chart1.Series["Voti"].Points.AddXY("telecomunicazioni", telecomunicazioni);



        }



        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

    

        private void ButtonAssenze_Click(object sender, EventArgs e)
        {
                Ait_RegistroElettronico.Assenze a1;
                String data = Convert.ToString(dateTimePicker1.Text);
                string Motivazione = Convert.ToString(textBoxMotivazione.Text);
                a1 = new Assenze(data, Motivazione);
            S.aggiungiAssenza(a1);
                dataGridViewAssenze.Rows.Add(data, Motivazione);
        }



        private void buttonSvuota_Click(object sender, EventArgs e)
        {
            textBoxNome.Text = "";
            textBoxCog.Text = "";
            textBoxEta.Text = "";
            textBoxPref.Text = "";
            textBoxClasse.Text = "";

        }

        private void radioButtonIta_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonEng.Checked)
            {
                tabPage0.Text = "Add Student";
                labelTitolo.Text = "ELECTRONIC REGISTER";
                labelNome.Text = "Name";
                labelCognome.Text = "Surname";
                labelEta.Text = "Age";
                labelMateriaPref.Text = "Favourite Subject";
                labelClasse.Text = "Class";
                buttonSvuota.Text = "CLEAR ALL TEXTBOXES";
                ButtonEliminaRow.Text = "DELETE SELECTED ROW";
                ButtonAggiorna.Text = "ADD";
                buttonCarica.Text = "LOAD FROM JSON FILE";
                buttonScarica.Text = "DOWNLOAD FROM JSON FILE";

                tabPage1.Text = "Student Report";
                labelTitolo2.Text = "STUDENT REPORT";
                labelInformazioni.Text = "BEFORE FILLING IN THE REPORT MAKE SURE YOU HAVE ADDED A STUDENT";
                labelInfo.Text = "Informatic";
                labelMate.Text = "Math";
                labelIta.Text = "Italian";
                labelIng.Text = "English";
                labelMot.Text = "P.E.";
                labelSist.Text = "systems and networks";
                labelTps.Text = "TPS";
                labelSto.Text = "History";
                labelTele.Text = "telecommunications";
                buttonAggVoti2.Text = "UPDATE MARKS";

                tabPage2.Text = "student absences";
                labelTitolo3.Text = "STUDENT ABSENCES";
                labelData.Text = "Date";
                labelMotivazione.Text = "Motivation";
                ButtonAssenze.Text = "ADD";


                tabPage4.Text = "Settings";
                labeltitolo5.Text = "SETTINGS";
                labelLingua.Text = "LANGUAGES";
                ButtonColButt.Text = "Change buttons color";
                ButtonCambSfo.Text = "Change backgroud color";
                ButtonImagineSf.Text = "Set an imagine as background";
                radioButtonIta.Text = "Italian";
                radioButtonEng.Text = "English";

            }

            else if (radioButtonIta.Checked)
            {
                tabPage0.Text = "Aggiungi Studente";
                labelTitolo.Text = "REGISTRO ELETTRONICO";
                labelNome.Text = "Nome";
                labelCognome.Text = "Cognome";
                labelEta.Text = "Eta";
                labelMateriaPref.Text = "Materia Preferita";
                labelClasse.Text = "Classe";
                buttonSvuota.Text = "SVUOTA CELLE";
                ButtonEliminaRow.Text = "ELIMINA RIGA";
                ButtonAggiorna.Text = "AGGIUNGI";
                buttonCarica.Text = "CARICA DA FILE JSON";
                buttonScarica.Text = "SCARICA DA FILE JSON";

                tabPage1.Text = "Pagella Studente";
                labelTitolo2.Text = "PAGELLA STUDENTE";
                labelInformazioni.Text = "PRIMA DI COMPILARE LA PAGELLA ASSICURATI DI AVER AGGIUNTO UNO STUDENTE";
                labelInfo.Text = "Informatica";
                labelMate.Text = "Matematica";
                labelIta.Text = "Italiano";
                labelIng.Text = "Inglese";
                labelMot.Text = "Motoria";
                labelSist.Text = "Sistemi";
                labelTps.Text = "TPS";
                labelSto.Text = "Storia";
                labelTele.Text = "telecomunicazioni";
                buttonAggVoti2.Text = "Aggiorna Voti";

                tabPage2.Text = "Assenze Studente";
                labelTitolo3.Text = "ASSENZE STUDENTE";
                labelData.Text = "Data";
                labelMotivazione.Text = "Motivazione";
                ButtonAssenze.Text = "AGGIUNGI";



                tabPage4.Text = "Impostazioni";
                labeltitolo5.Text = "IMPOSTAZIONI";
                labelLingua.Text = "LINGUE";
                ButtonColButt.Text = "Cambia colore dei button";
                ButtonCambSfo.Text = "Cambia colore sfondo";
                ButtonImagineSf.Text = "Imposta un immagine come sfondo";
                radioButtonIta.Text = "Italiano";
                radioButtonEng.Text = "Inglese";
            }

        }

        private void buttonCarica_Click_2(object sender, EventArgs e)
        {

            S.CaricaStudenti();
            AggiornaTabella();

        }

        private void buttonScarica_Click(object sender, EventArgs e)
        {
            try
            {
                S.salvaStudenti();
                MessageBox.Show("salvato con successo", "Stato", MessageBoxButtons.OK);


            }
            catch (Exception)
            {
                MessageBox.Show("Qualcosa è andato storto", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        private void buttonCaricaVoti_Click(object sender, EventArgs e)
        {
            S.CaricaVoti();
            AggiornaTabellaVoti();
        }

        private void buttonSalvaVoti_Click(object sender, EventArgs e)
        {
            try
            {
                S.salvaVoti();
                MessageBox.Show("salvato con successo", "Stato", MessageBoxButtons.OK);


            }
            catch (Exception)
            {
                MessageBox.Show("Qualcosa è andato storto", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonCaricaAssenze_Click(object sender, EventArgs e)
        {
            S.CaricaAssenze();
            AggiornaTabellaAssenze();
        }

        private void buttonSalvaAssenze_Click(object sender, EventArgs e)
        {
            try
            {
                S.salvaAssenze();
                MessageBox.Show("salvato con successo", "Stato", MessageBoxButtons.OK);


            }
            catch (Exception)
            {
                MessageBox.Show("Qualcosa è andato storto", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void AggiornaTabella()
        {
            dataGridViewStudente.Rows.Clear();
            for (int i = 0; i < S.Alunni.Count; i++)
            {
                string Nome = S.Alunni[i].Nome;
                string cognome = S.Alunni[i].cognome;
                string eta = Convert.ToString(S.Alunni[i].Eta);
                string MateriaPr = S.Alunni[i].MateriaPr;
                string classe = S.Alunni[i].classe;
                dataGridViewStudente.Rows.Add(Nome, cognome, eta, MateriaPr, classe);
                comboBoxElimina.Items.Add(S.Alunni[i].Nome +" "+ S.Alunni[i].cognome);
                comboBoxModifica.Items.Add(S.Alunni[i].Nome + " " + S.Alunni[i].cognome);
            }
        }

        public void AggiornaTabellaVoti()
        {
            dataGridViewPagella.Rows.Clear();
            for (int i = 0; i < S.Voti.Count; i++)
            {
                string informatica = S.Voti[i].informatica;
                string matematica = S.Voti[i].matematica;
                string italiano = S.Voti[i].italiano;
                string inglese = S.Voti[i].inglese;
                string motoria = S.Voti[i].motoria;
                string sistemi = S.Voti[i].sistemi;
                string storia = S.Voti[i].storia;
                string tps = S.Voti[i].tps;
                string telecomunicazioni = S.Voti[i].telecomunicazioni;
                dataGridViewPagella.Rows.Add(informatica, matematica, italiano, inglese, motoria, sistemi, storia, tps, telecomunicazioni);

            }
        }

        public void AggiornaTabellaAssenze()
        {
            dataGridViewAssenze.Rows.Clear();
            for (int i = 0; i < S.Assenze.Count; i++)
            {
                string Data = S.Assenze[i].Data;
                string Motivazione = S.Assenze[i].Motivazione;

                dataGridViewAssenze.Rows.Add(Data, Motivazione);

            }
        }

        private void buttonEliminaRigaAss_Click(object sender, EventArgs e)
        {
            if (this.dataGridViewAssenze.SelectedRows.Count > 0)
            {
                dataGridViewAssenze.Rows.RemoveAt(this.dataGridViewAssenze.SelectedRows[0].Index); //source:https://tinyurl.com/hk4nkr9w
            }
        }

        private void buttonElimina_Click(object sender, EventArgs e)
        {
            S.CaricaStudenti();
            int indice = Convert.ToInt32(comboBoxElimina.SelectedIndex);
            S.eliminaAlunno(indice);
            S.salvaStudenti();
            AggiornaTabella();
            MessageBox.Show("eliminato con successo");
        
        }

        private void buttonModifica_Click(object sender, EventArgs e)
        {   
                S.CaricaStudenti();
                int indice = Convert.ToInt32(comboBoxModifica.SelectedIndex);
                if (S.Alunni.Count >= indice)
                {
                    S.Alunni[indice].Nome = textBoxNomeM.Text;
                    S.Alunni[indice].cognome = textBoxCognomeM.Text;
                    S.Alunni[indice].Eta = Convert.ToInt32(textBoxEtaM.Text);
                    S.Alunni[indice].MateriaPr = textBoxMateriaPrM.Text;
                    S.Alunni[indice].classe = textBoxClasseM.Text;
                    S.salvaStudenti();
                AggiornaTabella();
     

                }
            }

        }
    }




