﻿
namespace Ait_RegistroElettronico
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelTitolo = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.LabelSocial = new System.Windows.Forms.Label();
            this.Instagram = new System.Windows.Forms.Button();
            this.Facebook = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.labelLingua = new System.Windows.Forms.Label();
            this.radioButtonEng = new System.Windows.Forms.RadioButton();
            this.radioButtonIta = new System.Windows.Forms.RadioButton();
            this.ButtonImagineSf = new System.Windows.Forms.Button();
            this.labeltitolo5 = new System.Windows.Forms.Label();
            this.ButtonCambSfo = new System.Windows.Forms.Button();
            this.ButtonColButt = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonEliminaRigaAss = new System.Windows.Forms.Button();
            this.buttonSalvaAssenze = new System.Windows.Forms.Button();
            this.buttonCaricaAssenze = new System.Windows.Forms.Button();
            this.labelMotivazione = new System.Windows.Forms.Label();
            this.labelData = new System.Windows.Forms.Label();
            this.textBoxMotivazione = new System.Windows.Forms.TextBox();
            this.dataGridViewAssenze = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ButtonAssenze = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.labelTitolo3 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonSalvaVoti = new System.Windows.Forms.Button();
            this.buttonCaricaVoti = new System.Windows.Forms.Button();
            this.labelInformazioni = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridViewPagella = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelMediaGen = new System.Windows.Forms.Label();
            this.buttonAggVoti2 = new System.Windows.Forms.Button();
            this.labelTele = new System.Windows.Forms.Label();
            this.labelTps = new System.Windows.Forms.Label();
            this.labelSto = new System.Windows.Forms.Label();
            this.labelSist = new System.Windows.Forms.Label();
            this.labelMot = new System.Windows.Forms.Label();
            this.labelIng = new System.Windows.Forms.Label();
            this.labelIta = new System.Windows.Forms.Label();
            this.labelMate = new System.Windows.Forms.Label();
            this.labelInfo = new System.Windows.Forms.Label();
            this.comboBoxTel = new System.Windows.Forms.ComboBox();
            this.comboBoxTps = new System.Windows.Forms.ComboBox();
            this.comboBoxSto = new System.Windows.Forms.ComboBox();
            this.comboBoxSist = new System.Windows.Forms.ComboBox();
            this.comboBoxMot = new System.Windows.Forms.ComboBox();
            this.comboBoxIng = new System.Windows.Forms.ComboBox();
            this.comboBoxIta = new System.Windows.Forms.ComboBox();
            this.comboBoxMate = new System.Windows.Forms.ComboBox();
            this.comboBoxInfo = new System.Windows.Forms.ComboBox();
            this.labelTitolo2 = new System.Windows.Forms.Label();
            this.tabPage0 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxClasseM = new System.Windows.Forms.TextBox();
            this.textBoxCognomeM = new System.Windows.Forms.TextBox();
            this.textBoxMateriaPrM = new System.Windows.Forms.TextBox();
            this.textBoxEtaM = new System.Windows.Forms.TextBox();
            this.textBoxNomeM = new System.Windows.Forms.TextBox();
            this.comboBoxModifica = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonElimina = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxElimina = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonScarica = new System.Windows.Forms.Button();
            this.buttonCarica = new System.Windows.Forms.Button();
            this.buttonSvuota = new System.Windows.Forms.Button();
            this.labelClasse = new System.Windows.Forms.Label();
            this.textBoxClasse = new System.Windows.Forms.TextBox();
            this.dataGridViewStudente = new System.Windows.Forms.DataGridView();
            this.ColonnaNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColonnaClasse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxCog = new System.Windows.Forms.TextBox();
            this.textBoxPref = new System.Windows.Forms.TextBox();
            this.textBoxEta = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.ButtonEliminaRow = new System.Windows.Forms.Button();
            this.labelCognome = new System.Windows.Forms.Label();
            this.ButtonAggiorna = new System.Windows.Forms.Button();
            this.labelMateriaPref = new System.Windows.Forms.Label();
            this.labelEta = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.buttonModifica = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAssenze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPagella)).BeginInit();
            this.tabPage0.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudente)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.labelTitolo);
            this.panel1.Location = new System.Drawing.Point(6, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1381, 40);
            this.panel1.TabIndex = 8;
            // 
            // labelTitolo
            // 
            this.labelTitolo.AutoSize = true;
            this.labelTitolo.Font = new System.Drawing.Font("Agency FB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitolo.Location = new System.Drawing.Point(499, 6);
            this.labelTitolo.Name = "labelTitolo";
            this.labelTitolo.Size = new System.Drawing.Size(197, 31);
            this.labelTitolo.TabIndex = 0;
            this.labelTitolo.Text = "REGISTRO ELETTRONICO";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Controls.Add(this.LabelSocial);
            this.tabPage5.Controls.Add(this.Instagram);
            this.tabPage5.Controls.Add(this.Facebook);
            this.tabPage5.Location = new System.Drawing.Point(4, 26);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage5.Size = new System.Drawing.Size(1277, 639);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Social";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(652, 54);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 59);
            this.label2.TabIndex = 13;
            this.label2.Text = "SOCIAL";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(1287, 0);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(86, 91);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 9;
            this.pictureBox5.TabStop = false;
            // 
            // LabelSocial
            // 
            this.LabelSocial.AutoSize = true;
            this.LabelSocial.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelSocial.Location = new System.Drawing.Point(563, 180);
            this.LabelSocial.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LabelSocial.Name = "LabelSocial";
            this.LabelSocial.Size = new System.Drawing.Size(299, 96);
            this.LabelSocial.TabIndex = 8;
            this.LabelSocial.Text = "Mail: Mourad131104@gmail.com\r\nNumero di telefono: +393457118188\r\n\r\n";
            // 
            // Instagram
            // 
            this.Instagram.BackColor = System.Drawing.Color.DarkBlue;
            this.Instagram.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.Instagram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Instagram.ForeColor = System.Drawing.Color.White;
            this.Instagram.Location = new System.Drawing.Point(471, 331);
            this.Instagram.Margin = new System.Windows.Forms.Padding(2);
            this.Instagram.Name = "Instagram";
            this.Instagram.Size = new System.Drawing.Size(213, 92);
            this.Instagram.TabIndex = 7;
            this.Instagram.Text = "Instagram";
            this.Instagram.UseVisualStyleBackColor = false;
            this.Instagram.Click += new System.EventHandler(this.Instagram_Click_1);
            // 
            // Facebook
            // 
            this.Facebook.BackColor = System.Drawing.Color.DarkBlue;
            this.Facebook.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.Facebook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Facebook.ForeColor = System.Drawing.Color.White;
            this.Facebook.Location = new System.Drawing.Point(725, 331);
            this.Facebook.Margin = new System.Windows.Forms.Padding(2);
            this.Facebook.Name = "Facebook";
            this.Facebook.Size = new System.Drawing.Size(213, 92);
            this.Facebook.TabIndex = 6;
            this.Facebook.Text = "Facebook";
            this.Facebook.UseVisualStyleBackColor = false;
            this.Facebook.Click += new System.EventHandler(this.Facebook_Click_1);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.labelLingua);
            this.tabPage4.Controls.Add(this.radioButtonEng);
            this.tabPage4.Controls.Add(this.radioButtonIta);
            this.tabPage4.Controls.Add(this.ButtonImagineSf);
            this.tabPage4.Controls.Add(this.labeltitolo5);
            this.tabPage4.Controls.Add(this.ButtonCambSfo);
            this.tabPage4.Controls.Add(this.ButtonColButt);
            this.tabPage4.Controls.Add(this.pictureBox6);
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1277, 639);
            this.tabPage4.TabIndex = 5;
            this.tabPage4.Text = "Impostazioni";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // labelLingua
            // 
            this.labelLingua.AutoSize = true;
            this.labelLingua.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLingua.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelLingua.Location = new System.Drawing.Point(1029, 182);
            this.labelLingua.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLingua.Name = "labelLingua";
            this.labelLingua.Size = new System.Drawing.Size(98, 39);
            this.labelLingua.TabIndex = 17;
            this.labelLingua.Text = "LINGUA:";
            // 
            // radioButtonEng
            // 
            this.radioButtonEng.AutoSize = true;
            this.radioButtonEng.Location = new System.Drawing.Point(1036, 300);
            this.radioButtonEng.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonEng.Name = "radioButtonEng";
            this.radioButtonEng.Size = new System.Drawing.Size(59, 21);
            this.radioButtonEng.TabIndex = 15;
            this.radioButtonEng.Text = "INGLESE";
            this.radioButtonEng.UseVisualStyleBackColor = true;
            // 
            // radioButtonIta
            // 
            this.radioButtonIta.AutoSize = true;
            this.radioButtonIta.Checked = true;
            this.radioButtonIta.Location = new System.Drawing.Point(1036, 257);
            this.radioButtonIta.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonIta.Name = "radioButtonIta";
            this.radioButtonIta.Size = new System.Drawing.Size(69, 21);
            this.radioButtonIta.TabIndex = 14;
            this.radioButtonIta.TabStop = true;
            this.radioButtonIta.Text = "ITALIANO";
            this.radioButtonIta.UseVisualStyleBackColor = true;
            this.radioButtonIta.CheckedChanged += new System.EventHandler(this.radioButtonIta_CheckedChanged);
            // 
            // ButtonImagineSf
            // 
            this.ButtonImagineSf.BackColor = System.Drawing.Color.DarkBlue;
            this.ButtonImagineSf.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.ButtonImagineSf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonImagineSf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonImagineSf.ForeColor = System.Drawing.Color.White;
            this.ButtonImagineSf.Location = new System.Drawing.Point(680, 141);
            this.ButtonImagineSf.Margin = new System.Windows.Forms.Padding(2);
            this.ButtonImagineSf.Name = "ButtonImagineSf";
            this.ButtonImagineSf.Size = new System.Drawing.Size(225, 137);
            this.ButtonImagineSf.TabIndex = 13;
            this.ButtonImagineSf.Text = "Carica un immagine come sfondo\r\n";
            this.ButtonImagineSf.UseVisualStyleBackColor = false;
            this.ButtonImagineSf.Click += new System.EventHandler(this.ButtonImagineSf_Click);
            // 
            // labeltitolo5
            // 
            this.labeltitolo5.AutoSize = true;
            this.labeltitolo5.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltitolo5.ForeColor = System.Drawing.Color.DarkBlue;
            this.labeltitolo5.Location = new System.Drawing.Point(547, 14);
            this.labeltitolo5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labeltitolo5.Name = "labeltitolo5";
            this.labeltitolo5.Size = new System.Drawing.Size(235, 59);
            this.labeltitolo5.TabIndex = 12;
            this.labeltitolo5.Text = "IMPOSTAZIONI";
            // 
            // ButtonCambSfo
            // 
            this.ButtonCambSfo.BackColor = System.Drawing.Color.DarkBlue;
            this.ButtonCambSfo.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.ButtonCambSfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonCambSfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCambSfo.ForeColor = System.Drawing.Color.White;
            this.ButtonCambSfo.Location = new System.Drawing.Point(412, 141);
            this.ButtonCambSfo.Margin = new System.Windows.Forms.Padding(2);
            this.ButtonCambSfo.Name = "ButtonCambSfo";
            this.ButtonCambSfo.Size = new System.Drawing.Size(225, 137);
            this.ButtonCambSfo.TabIndex = 10;
            this.ButtonCambSfo.Text = "Cambia colore sfondo";
            this.ButtonCambSfo.UseVisualStyleBackColor = false;
            this.ButtonCambSfo.Click += new System.EventHandler(this.button2_Click);
            // 
            // ButtonColButt
            // 
            this.ButtonColButt.BackColor = System.Drawing.Color.DarkBlue;
            this.ButtonColButt.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.ButtonColButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonColButt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonColButt.ForeColor = System.Drawing.Color.White;
            this.ButtonColButt.Location = new System.Drawing.Point(557, 313);
            this.ButtonColButt.Margin = new System.Windows.Forms.Padding(2);
            this.ButtonColButt.Name = "ButtonColButt";
            this.ButtonColButt.Size = new System.Drawing.Size(225, 137);
            this.ButtonColButt.TabIndex = 9;
            this.ButtonColButt.Text = "Cambia colore button";
            this.ButtonColButt.UseVisualStyleBackColor = false;
            this.ButtonColButt.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(1289, 0);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(86, 91);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.buttonEliminaRigaAss);
            this.tabPage2.Controls.Add(this.buttonSalvaAssenze);
            this.tabPage2.Controls.Add(this.buttonCaricaAssenze);
            this.tabPage2.Controls.Add(this.labelMotivazione);
            this.tabPage2.Controls.Add(this.labelData);
            this.tabPage2.Controls.Add(this.textBoxMotivazione);
            this.tabPage2.Controls.Add(this.dataGridViewAssenze);
            this.tabPage2.Controls.Add(this.dateTimePicker1);
            this.tabPage2.Controls.Add(this.ButtonAssenze);
            this.tabPage2.Controls.Add(this.pictureBox3);
            this.tabPage2.Controls.Add(this.labelTitolo3);
            this.tabPage2.Font = new System.Drawing.Font("Agency FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(1277, 639);
            this.tabPage2.TabIndex = 8;
            this.tabPage2.Text = "Assenze Studente";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // buttonEliminaRigaAss
            // 
            this.buttonEliminaRigaAss.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.buttonEliminaRigaAss.FlatAppearance.BorderSize = 2;
            this.buttonEliminaRigaAss.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEliminaRigaAss.Location = new System.Drawing.Point(767, 547);
            this.buttonEliminaRigaAss.Margin = new System.Windows.Forms.Padding(2);
            this.buttonEliminaRigaAss.Name = "buttonEliminaRigaAss";
            this.buttonEliminaRigaAss.Size = new System.Drawing.Size(363, 37);
            this.buttonEliminaRigaAss.TabIndex = 59;
            this.buttonEliminaRigaAss.Text = "ELIMINA RIGA";
            this.buttonEliminaRigaAss.UseVisualStyleBackColor = true;
            this.buttonEliminaRigaAss.Click += new System.EventHandler(this.buttonEliminaRigaAss_Click);
            // 
            // buttonSalvaAssenze
            // 
            this.buttonSalvaAssenze.BackColor = System.Drawing.Color.Purple;
            this.buttonSalvaAssenze.FlatAppearance.BorderColor = System.Drawing.Color.Purple;
            this.buttonSalvaAssenze.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSalvaAssenze.Font = new System.Drawing.Font("Agency FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalvaAssenze.ForeColor = System.Drawing.Color.White;
            this.buttonSalvaAssenze.Location = new System.Drawing.Point(180, 4);
            this.buttonSalvaAssenze.Margin = new System.Windows.Forms.Padding(2);
            this.buttonSalvaAssenze.Name = "buttonSalvaAssenze";
            this.buttonSalvaAssenze.Size = new System.Drawing.Size(155, 59);
            this.buttonSalvaAssenze.TabIndex = 58;
            this.buttonSalvaAssenze.Text = "SALVA SU FILE JSON ASSRNZE";
            this.buttonSalvaAssenze.UseVisualStyleBackColor = false;
            this.buttonSalvaAssenze.Click += new System.EventHandler(this.buttonSalvaAssenze_Click);
            // 
            // buttonCaricaAssenze
            // 
            this.buttonCaricaAssenze.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.buttonCaricaAssenze.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCaricaAssenze.Font = new System.Drawing.Font("Agency FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCaricaAssenze.Location = new System.Drawing.Point(2, 4);
            this.buttonCaricaAssenze.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCaricaAssenze.Name = "buttonCaricaAssenze";
            this.buttonCaricaAssenze.Size = new System.Drawing.Size(151, 59);
            this.buttonCaricaAssenze.TabIndex = 57;
            this.buttonCaricaAssenze.Text = "CARICA DA FILE JSON  ASSENZE";
            this.buttonCaricaAssenze.UseVisualStyleBackColor = false;
            this.buttonCaricaAssenze.Click += new System.EventHandler(this.buttonCaricaAssenze_Click);
            // 
            // labelMotivazione
            // 
            this.labelMotivazione.AutoSize = true;
            this.labelMotivazione.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMotivazione.Location = new System.Drawing.Point(392, 242);
            this.labelMotivazione.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMotivazione.Name = "labelMotivazione";
            this.labelMotivazione.Size = new System.Drawing.Size(89, 24);
            this.labelMotivazione.TabIndex = 56;
            this.labelMotivazione.Text = "MOTIVAZIONE";
            // 
            // labelData
            // 
            this.labelData.AutoSize = true;
            this.labelData.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelData.Location = new System.Drawing.Point(415, 115);
            this.labelData.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelData.Name = "labelData";
            this.labelData.Size = new System.Drawing.Size(43, 24);
            this.labelData.TabIndex = 55;
            this.labelData.Text = "DATA";
            // 
            // textBoxMotivazione
            // 
            this.textBoxMotivazione.Location = new System.Drawing.Point(337, 277);
            this.textBoxMotivazione.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxMotivazione.Multiline = true;
            this.textBoxMotivazione.Name = "textBoxMotivazione";
            this.textBoxMotivazione.Size = new System.Drawing.Size(200, 107);
            this.textBoxMotivazione.TabIndex = 54;
            this.textBoxMotivazione.Text = "Malattia";
            // 
            // dataGridViewAssenze
            // 
            this.dataGridViewAssenze.AllowUserToAddRows = false;
            this.dataGridViewAssenze.AllowUserToResizeRows = false;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewAssenze.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridViewAssenze.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAssenze.BackgroundColor = System.Drawing.Color.DarkBlue;
            this.dataGridViewAssenze.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewAssenze.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewAssenze.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Agency FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAssenze.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewAssenze.ColumnHeadersHeight = 50;
            this.dataGridViewAssenze.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Agency FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewAssenze.DefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridViewAssenze.EnableHeadersVisualStyles = false;
            this.dataGridViewAssenze.Location = new System.Drawing.Point(767, 115);
            this.dataGridViewAssenze.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewAssenze.Name = "dataGridViewAssenze";
            this.dataGridViewAssenze.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Agency FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAssenze.RowHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dataGridViewAssenze.RowHeadersWidth = 82;
            this.dataGridViewAssenze.RowTemplate.Height = 50;
            this.dataGridViewAssenze.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAssenze.Size = new System.Drawing.Size(363, 383);
            this.dataGridViewAssenze.TabIndex = 51;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "ASSENZA";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "MOTIVAZIONE";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(364, 177);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.MaxDate = new System.DateTime(2024, 6, 8, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(135, 27);
            this.dateTimePicker1.TabIndex = 53;
            this.dateTimePicker1.UseWaitCursor = true;
            this.dateTimePicker1.Value = new System.DateTime(2022, 1, 19, 0, 0, 0, 0);
            // 
            // ButtonAssenze
            // 
            this.ButtonAssenze.BackColor = System.Drawing.Color.DarkBlue;
            this.ButtonAssenze.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.ButtonAssenze.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonAssenze.ForeColor = System.Drawing.Color.White;
            this.ButtonAssenze.Location = new System.Drawing.Point(767, 502);
            this.ButtonAssenze.Margin = new System.Windows.Forms.Padding(2);
            this.ButtonAssenze.Name = "ButtonAssenze";
            this.ButtonAssenze.Size = new System.Drawing.Size(363, 31);
            this.ButtonAssenze.TabIndex = 52;
            this.ButtonAssenze.Text = "AGGIUNGI";
            this.ButtonAssenze.UseVisualStyleBackColor = false;
            this.ButtonAssenze.Click += new System.EventHandler(this.ButtonAssenze_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1287, 4);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(86, 91);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 50;
            this.pictureBox3.TabStop = false;
            // 
            // labelTitolo3
            // 
            this.labelTitolo3.AutoSize = true;
            this.labelTitolo3.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitolo3.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelTitolo3.Location = new System.Drawing.Point(509, 4);
            this.labelTitolo3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTitolo3.Name = "labelTitolo3";
            this.labelTitolo3.Size = new System.Drawing.Size(328, 59);
            this.labelTitolo3.TabIndex = 21;
            this.labelTitolo3.Text = "ASSENZE STUDENTE";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.buttonSalvaVoti);
            this.tabPage1.Controls.Add(this.buttonCaricaVoti);
            this.tabPage1.Controls.Add(this.labelInformazioni);
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.dataGridViewPagella);
            this.tabPage1.Controls.Add(this.labelMediaGen);
            this.tabPage1.Controls.Add(this.buttonAggVoti2);
            this.tabPage1.Controls.Add(this.labelTele);
            this.tabPage1.Controls.Add(this.labelTps);
            this.tabPage1.Controls.Add(this.labelSto);
            this.tabPage1.Controls.Add(this.labelSist);
            this.tabPage1.Controls.Add(this.labelMot);
            this.tabPage1.Controls.Add(this.labelIng);
            this.tabPage1.Controls.Add(this.labelIta);
            this.tabPage1.Controls.Add(this.labelMate);
            this.tabPage1.Controls.Add(this.labelInfo);
            this.tabPage1.Controls.Add(this.comboBoxTel);
            this.tabPage1.Controls.Add(this.comboBoxTps);
            this.tabPage1.Controls.Add(this.comboBoxSto);
            this.tabPage1.Controls.Add(this.comboBoxSist);
            this.tabPage1.Controls.Add(this.comboBoxMot);
            this.tabPage1.Controls.Add(this.comboBoxIng);
            this.tabPage1.Controls.Add(this.comboBoxIta);
            this.tabPage1.Controls.Add(this.comboBoxMate);
            this.tabPage1.Controls.Add(this.comboBoxInfo);
            this.tabPage1.Controls.Add(this.labelTitolo2);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(1277, 639);
            this.tabPage1.TabIndex = 7;
            this.tabPage1.Text = "Pagella Studente";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // buttonSalvaVoti
            // 
            this.buttonSalvaVoti.BackColor = System.Drawing.Color.Purple;
            this.buttonSalvaVoti.FlatAppearance.BorderColor = System.Drawing.Color.Purple;
            this.buttonSalvaVoti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSalvaVoti.ForeColor = System.Drawing.Color.White;
            this.buttonSalvaVoti.Location = new System.Drawing.Point(180, 4);
            this.buttonSalvaVoti.Margin = new System.Windows.Forms.Padding(2);
            this.buttonSalvaVoti.Name = "buttonSalvaVoti";
            this.buttonSalvaVoti.Size = new System.Drawing.Size(155, 57);
            this.buttonSalvaVoti.TabIndex = 53;
            this.buttonSalvaVoti.Text = "SALVA SU FILE JSON VOTI";
            this.buttonSalvaVoti.UseVisualStyleBackColor = false;
            this.buttonSalvaVoti.Click += new System.EventHandler(this.buttonSalvaVoti_Click);
            // 
            // buttonCaricaVoti
            // 
            this.buttonCaricaVoti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.buttonCaricaVoti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCaricaVoti.Location = new System.Drawing.Point(2, 4);
            this.buttonCaricaVoti.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCaricaVoti.Name = "buttonCaricaVoti";
            this.buttonCaricaVoti.Size = new System.Drawing.Size(151, 57);
            this.buttonCaricaVoti.TabIndex = 52;
            this.buttonCaricaVoti.Text = "CARICA DA FILE JSON  VOTI";
            this.buttonCaricaVoti.UseVisualStyleBackColor = false;
            this.buttonCaricaVoti.Click += new System.EventHandler(this.buttonCaricaVoti_Click);
            // 
            // labelInformazioni
            // 
            this.labelInformazioni.AutoSize = true;
            this.labelInformazioni.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInformazioni.Location = new System.Drawing.Point(208, 89);
            this.labelInformazioni.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInformazioni.Name = "labelInformazioni";
            this.labelInformazioni.Size = new System.Drawing.Size(158, 51);
            this.labelInformazioni.TabIndex = 51;
            this.labelInformazioni.Text = "PRIMA DI COMPILARE LA PAGELLA\r\n ASSICURATI DI AVER AGGIUNTO\r\n UNO STUDENTE";
            // 
            // chart1
            // 
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            this.chart1.Location = new System.Drawing.Point(1045, 127);
            this.chart1.Margin = new System.Windows.Forms.Padding(2);
            this.chart1.Name = "chart1";
            series3.ChartArea = "ChartArea1";
            series3.Name = "Voti";
            this.chart1.Series.Add(series3);
            this.chart1.Size = new System.Drawing.Size(249, 404);
            this.chart1.TabIndex = 50;
            this.chart1.Text = "chart1";
            title3.Name = "Voti";
            title3.Text = "Voti";
            this.chart1.Titles.Add(title3);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1289, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(86, 91);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 49;
            this.pictureBox2.TabStop = false;
            // 
            // dataGridViewPagella
            // 
            this.dataGridViewPagella.AllowUserToAddRows = false;
            this.dataGridViewPagella.AllowUserToResizeRows = false;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewPagella.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewPagella.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPagella.BackgroundColor = System.Drawing.Color.DarkBlue;
            this.dataGridViewPagella.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewPagella.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewPagella.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPagella.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridViewPagella.ColumnHeadersHeight = 50;
            this.dataGridViewPagella.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column1});
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPagella.DefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridViewPagella.EnableHeadersVisualStyles = false;
            this.dataGridViewPagella.Location = new System.Drawing.Point(531, 63);
            this.dataGridViewPagella.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewPagella.Name = "dataGridViewPagella";
            this.dataGridViewPagella.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPagella.RowHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridViewPagella.RowHeadersWidth = 82;
            this.dataGridViewPagella.RowTemplate.Height = 50;
            this.dataGridViewPagella.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPagella.Size = new System.Drawing.Size(304, 326);
            this.dataGridViewPagella.TabIndex = 42;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "MATERIA";
            this.Column5.MinimumWidth = 10;
            this.Column5.Name = "Column5";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "VOTI";
            this.Column1.MinimumWidth = 10;
            this.Column1.Name = "Column1";
            // 
            // labelMediaGen
            // 
            this.labelMediaGen.AutoSize = true;
            this.labelMediaGen.BackColor = System.Drawing.Color.Yellow;
            this.labelMediaGen.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelMediaGen.Font = new System.Drawing.Font("Agency FB", 25.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMediaGen.Location = new System.Drawing.Point(314, 462);
            this.labelMediaGen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMediaGen.Name = "labelMediaGen";
            this.labelMediaGen.Size = new System.Drawing.Size(0, 42);
            this.labelMediaGen.TabIndex = 41;
            // 
            // buttonAggVoti2
            // 
            this.buttonAggVoti2.BackColor = System.Drawing.Color.DarkBlue;
            this.buttonAggVoti2.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.buttonAggVoti2.FlatAppearance.BorderSize = 2;
            this.buttonAggVoti2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAggVoti2.ForeColor = System.Drawing.Color.White;
            this.buttonAggVoti2.Location = new System.Drawing.Point(531, 410);
            this.buttonAggVoti2.Margin = new System.Windows.Forms.Padding(2);
            this.buttonAggVoti2.Name = "buttonAggVoti2";
            this.buttonAggVoti2.Size = new System.Drawing.Size(304, 68);
            this.buttonAggVoti2.TabIndex = 40;
            this.buttonAggVoti2.Text = "AGGIORNA VOTI";
            this.buttonAggVoti2.UseVisualStyleBackColor = false;
            this.buttonAggVoti2.Click += new System.EventHandler(this.buttonAggVoti2_Click);
            // 
            // labelTele
            // 
            this.labelTele.AutoSize = true;
            this.labelTele.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTele.Location = new System.Drawing.Point(297, 384);
            this.labelTele.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTele.Name = "labelTele";
            this.labelTele.Size = new System.Drawing.Size(99, 17);
            this.labelTele.TabIndex = 38;
            this.labelTele.Text = "TELECOMUNICAZIONI";
            // 
            // labelTps
            // 
            this.labelTps.AutoSize = true;
            this.labelTps.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTps.Location = new System.Drawing.Point(334, 322);
            this.labelTps.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTps.Name = "labelTps";
            this.labelTps.Size = new System.Drawing.Size(27, 17);
            this.labelTps.TabIndex = 37;
            this.labelTps.Text = "TPS";
            // 
            // labelSto
            // 
            this.labelSto.AutoSize = true;
            this.labelSto.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSto.Location = new System.Drawing.Point(321, 259);
            this.labelSto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSto.Name = "labelSto";
            this.labelSto.Size = new System.Drawing.Size(43, 17);
            this.labelSto.TabIndex = 36;
            this.labelSto.Text = "STORIA";
            // 
            // labelSist
            // 
            this.labelSist.AutoSize = true;
            this.labelSist.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSist.Location = new System.Drawing.Point(319, 204);
            this.labelSist.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSist.Name = "labelSist";
            this.labelSist.Size = new System.Drawing.Size(45, 17);
            this.labelSist.TabIndex = 35;
            this.labelSist.Text = "SISTEMI";
            // 
            // labelMot
            // 
            this.labelMot.AutoSize = true;
            this.labelMot.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMot.Location = new System.Drawing.Point(208, 456);
            this.labelMot.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMot.Name = "labelMot";
            this.labelMot.Size = new System.Drawing.Size(51, 17);
            this.labelMot.TabIndex = 34;
            this.labelMot.Text = "MOTORIA";
            // 
            // labelIng
            // 
            this.labelIng.AutoSize = true;
            this.labelIng.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIng.Location = new System.Drawing.Point(208, 384);
            this.labelIng.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelIng.Name = "labelIng";
            this.labelIng.Size = new System.Drawing.Size(41, 17);
            this.labelIng.TabIndex = 33;
            this.labelIng.Text = "INGLESE";
            // 
            // labelIta
            // 
            this.labelIta.AutoSize = true;
            this.labelIta.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIta.Location = new System.Drawing.Point(208, 322);
            this.labelIta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelIta.Name = "labelIta";
            this.labelIta.Size = new System.Drawing.Size(51, 17);
            this.labelIta.TabIndex = 32;
            this.labelIta.Text = "ITALIANO";
            // 
            // labelMate
            // 
            this.labelMate.AutoSize = true;
            this.labelMate.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMate.Location = new System.Drawing.Point(208, 259);
            this.labelMate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMate.Name = "labelMate";
            this.labelMate.Size = new System.Drawing.Size(72, 17);
            this.labelMate.TabIndex = 31;
            this.labelMate.Text = "MATEMATICA";
            // 
            // labelInfo
            // 
            this.labelInfo.AutoSize = true;
            this.labelInfo.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInfo.Location = new System.Drawing.Point(208, 204);
            this.labelInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(71, 17);
            this.labelInfo.TabIndex = 30;
            this.labelInfo.Text = "INFORMATICA";
            // 
            // comboBoxTel
            // 
            this.comboBoxTel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTel.FormattingEnabled = true;
            this.comboBoxTel.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTel.Location = new System.Drawing.Point(321, 407);
            this.comboBoxTel.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxTel.Name = "comboBoxTel";
            this.comboBoxTel.Size = new System.Drawing.Size(48, 25);
            this.comboBoxTel.TabIndex = 8;
            // 
            // comboBoxTps
            // 
            this.comboBoxTps.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTps.FormattingEnabled = true;
            this.comboBoxTps.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTps.Location = new System.Drawing.Point(321, 345);
            this.comboBoxTps.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxTps.Name = "comboBoxTps";
            this.comboBoxTps.Size = new System.Drawing.Size(48, 25);
            this.comboBoxTps.TabIndex = 6;
            // 
            // comboBoxSto
            // 
            this.comboBoxSto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSto.FormattingEnabled = true;
            this.comboBoxSto.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSto.Location = new System.Drawing.Point(321, 283);
            this.comboBoxSto.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSto.Name = "comboBoxSto";
            this.comboBoxSto.Size = new System.Drawing.Size(48, 25);
            this.comboBoxSto.TabIndex = 4;
            // 
            // comboBoxSist
            // 
            this.comboBoxSist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSist.FormattingEnabled = true;
            this.comboBoxSist.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSist.Location = new System.Drawing.Point(321, 228);
            this.comboBoxSist.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSist.Name = "comboBoxSist";
            this.comboBoxSist.Size = new System.Drawing.Size(48, 25);
            this.comboBoxSist.TabIndex = 2;
            // 
            // comboBoxMot
            // 
            this.comboBoxMot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMot.FormattingEnabled = true;
            this.comboBoxMot.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxMot.Location = new System.Drawing.Point(211, 479);
            this.comboBoxMot.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxMot.Name = "comboBoxMot";
            this.comboBoxMot.Size = new System.Drawing.Size(48, 25);
            this.comboBoxMot.TabIndex = 9;
            // 
            // comboBoxIng
            // 
            this.comboBoxIng.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxIng.FormattingEnabled = true;
            this.comboBoxIng.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIng.Location = new System.Drawing.Point(211, 407);
            this.comboBoxIng.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxIng.Name = "comboBoxIng";
            this.comboBoxIng.Size = new System.Drawing.Size(48, 25);
            this.comboBoxIng.TabIndex = 7;
            // 
            // comboBoxIta
            // 
            this.comboBoxIta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxIta.FormattingEnabled = true;
            this.comboBoxIta.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIta.Location = new System.Drawing.Point(211, 345);
            this.comboBoxIta.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxIta.Name = "comboBoxIta";
            this.comboBoxIta.Size = new System.Drawing.Size(48, 25);
            this.comboBoxIta.TabIndex = 5;
            // 
            // comboBoxMate
            // 
            this.comboBoxMate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMate.FormattingEnabled = true;
            this.comboBoxMate.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxMate.Location = new System.Drawing.Point(211, 283);
            this.comboBoxMate.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxMate.Name = "comboBoxMate";
            this.comboBoxMate.Size = new System.Drawing.Size(48, 25);
            this.comboBoxMate.TabIndex = 3;
            // 
            // comboBoxInfo
            // 
            this.comboBoxInfo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxInfo.FormattingEnabled = true;
            this.comboBoxInfo.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxInfo.Location = new System.Drawing.Point(211, 228);
            this.comboBoxInfo.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxInfo.Name = "comboBoxInfo";
            this.comboBoxInfo.Size = new System.Drawing.Size(48, 25);
            this.comboBoxInfo.TabIndex = 1;
            // 
            // labelTitolo2
            // 
            this.labelTitolo2.AutoSize = true;
            this.labelTitolo2.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitolo2.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelTitolo2.Location = new System.Drawing.Point(521, 2);
            this.labelTitolo2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTitolo2.Name = "labelTitolo2";
            this.labelTitolo2.Size = new System.Drawing.Size(318, 59);
            this.labelTitolo2.TabIndex = 20;
            this.labelTitolo2.Text = "PAGELLA STUDENTE";
            // 
            // tabPage0
            // 
            this.tabPage0.Controls.Add(this.label10);
            this.tabPage0.Controls.Add(this.buttonModifica);
            this.tabPage0.Controls.Add(this.label9);
            this.tabPage0.Controls.Add(this.label8);
            this.tabPage0.Controls.Add(this.label7);
            this.tabPage0.Controls.Add(this.label6);
            this.tabPage0.Controls.Add(this.label5);
            this.tabPage0.Controls.Add(this.textBoxClasseM);
            this.tabPage0.Controls.Add(this.textBoxCognomeM);
            this.tabPage0.Controls.Add(this.textBoxMateriaPrM);
            this.tabPage0.Controls.Add(this.textBoxEtaM);
            this.tabPage0.Controls.Add(this.textBoxNomeM);
            this.tabPage0.Controls.Add(this.comboBoxModifica);
            this.tabPage0.Controls.Add(this.panel3);
            this.tabPage0.Controls.Add(this.buttonElimina);
            this.tabPage0.Controls.Add(this.label3);
            this.tabPage0.Controls.Add(this.comboBoxElimina);
            this.tabPage0.Controls.Add(this.panel2);
            this.tabPage0.Controls.Add(this.buttonScarica);
            this.tabPage0.Controls.Add(this.buttonCarica);
            this.tabPage0.Controls.Add(this.buttonSvuota);
            this.tabPage0.Controls.Add(this.labelClasse);
            this.tabPage0.Controls.Add(this.textBoxClasse);
            this.tabPage0.Controls.Add(this.dataGridViewStudente);
            this.tabPage0.Controls.Add(this.textBoxCog);
            this.tabPage0.Controls.Add(this.textBoxPref);
            this.tabPage0.Controls.Add(this.textBoxEta);
            this.tabPage0.Controls.Add(this.textBoxNome);
            this.tabPage0.Controls.Add(this.ButtonEliminaRow);
            this.tabPage0.Controls.Add(this.labelCognome);
            this.tabPage0.Controls.Add(this.ButtonAggiorna);
            this.tabPage0.Controls.Add(this.labelMateriaPref);
            this.tabPage0.Controls.Add(this.labelEta);
            this.tabPage0.Controls.Add(this.labelNome);
            this.tabPage0.Location = new System.Drawing.Point(4, 26);
            this.tabPage0.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage0.Name = "tabPage0";
            this.tabPage0.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage0.Size = new System.Drawing.Size(1277, 646);
            this.tabPage0.TabIndex = 6;
            this.tabPage0.Text = "Aggiungi Studente";
            this.tabPage0.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(967, 476);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 24);
            this.label9.TabIndex = 65;
            this.label9.Text = "CLASSE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1129, 405);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 24);
            this.label8.TabIndex = 64;
            this.label8.Text = "MATERIA PREFERITA";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(977, 405);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 24);
            this.label7.TabIndex = 63;
            this.label7.Text = "ETA";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1162, 338);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 24);
            this.label6.TabIndex = 62;
            this.label6.Text = "COGNOME";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(967, 338);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 24);
            this.label5.TabIndex = 61;
            this.label5.Text = "NOME";
            // 
            // textBoxClasseM
            // 
            this.textBoxClasseM.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxClasseM.Location = new System.Drawing.Point(931, 502);
            this.textBoxClasseM.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxClasseM.Name = "textBoxClasseM";
            this.textBoxClasseM.Size = new System.Drawing.Size(123, 30);
            this.textBoxClasseM.TabIndex = 60;
            // 
            // textBoxCognomeM
            // 
            this.textBoxCognomeM.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCognomeM.Location = new System.Drawing.Point(1136, 364);
            this.textBoxCognomeM.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxCognomeM.Name = "textBoxCognomeM";
            this.textBoxCognomeM.Size = new System.Drawing.Size(120, 30);
            this.textBoxCognomeM.TabIndex = 57;
            // 
            // textBoxMateriaPrM
            // 
            this.textBoxMateriaPrM.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMateriaPrM.Location = new System.Drawing.Point(1133, 431);
            this.textBoxMateriaPrM.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxMateriaPrM.Name = "textBoxMateriaPrM";
            this.textBoxMateriaPrM.Size = new System.Drawing.Size(123, 30);
            this.textBoxMateriaPrM.TabIndex = 59;
            // 
            // textBoxEtaM
            // 
            this.textBoxEtaM.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEtaM.Location = new System.Drawing.Point(934, 431);
            this.textBoxEtaM.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEtaM.Name = "textBoxEtaM";
            this.textBoxEtaM.Size = new System.Drawing.Size(120, 30);
            this.textBoxEtaM.TabIndex = 58;
            // 
            // textBoxNomeM
            // 
            this.textBoxNomeM.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomeM.Location = new System.Drawing.Point(934, 364);
            this.textBoxNomeM.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxNomeM.Name = "textBoxNomeM";
            this.textBoxNomeM.Size = new System.Drawing.Size(120, 30);
            this.textBoxNomeM.TabIndex = 56;
            // 
            // comboBoxModifica
            // 
            this.comboBoxModifica.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxModifica.FormattingEnabled = true;
            this.comboBoxModifica.Location = new System.Drawing.Point(998, 291);
            this.comboBoxModifica.Name = "comboBoxModifica";
            this.comboBoxModifica.Size = new System.Drawing.Size(187, 25);
            this.comboBoxModifica.TabIndex = 55;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(945, 234);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(302, 51);
            this.panel3.TabIndex = 54;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Agency FB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(76, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 31);
            this.label4.TabIndex = 0;
            this.label4.Text = "SEZIONE MODIFICA";
            // 
            // buttonElimina
            // 
            this.buttonElimina.BackColor = System.Drawing.Color.DarkBlue;
            this.buttonElimina.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.buttonElimina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonElimina.ForeColor = System.Drawing.Color.White;
            this.buttonElimina.Location = new System.Drawing.Point(1000, 147);
            this.buttonElimina.Margin = new System.Windows.Forms.Padding(2);
            this.buttonElimina.Name = "buttonElimina";
            this.buttonElimina.Size = new System.Drawing.Size(185, 51);
            this.buttonElimina.TabIndex = 53;
            this.buttonElimina.Text = "ELIMINA";
            this.buttonElimina.UseVisualStyleBackColor = false;
            this.buttonElimina.Click += new System.EventHandler(this.buttonElimina_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(997, 72);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 17);
            this.label3.TabIndex = 52;
            this.label3.Text = "SELEZIONA LO STUDENTE CHE VUOI ELIMINARE";
            // 
            // comboBoxElimina
            // 
            this.comboBoxElimina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxElimina.FormattingEnabled = true;
            this.comboBoxElimina.Location = new System.Drawing.Point(1000, 92);
            this.comboBoxElimina.Name = "comboBoxElimina";
            this.comboBoxElimina.Size = new System.Drawing.Size(187, 25);
            this.comboBoxElimina.TabIndex = 34;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(945, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(302, 51);
            this.panel2.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(90, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "SEZIONE ELIMINA";
            // 
            // buttonScarica
            // 
            this.buttonScarica.BackColor = System.Drawing.Color.Purple;
            this.buttonScarica.FlatAppearance.BorderColor = System.Drawing.Color.Purple;
            this.buttonScarica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonScarica.ForeColor = System.Drawing.Color.White;
            this.buttonScarica.Location = new System.Drawing.Point(191, 2);
            this.buttonScarica.Margin = new System.Windows.Forms.Padding(2);
            this.buttonScarica.Name = "buttonScarica";
            this.buttonScarica.Size = new System.Drawing.Size(155, 51);
            this.buttonScarica.TabIndex = 29;
            this.buttonScarica.Text = "SALVA SU FILE JSON STUDENTI";
            this.buttonScarica.UseVisualStyleBackColor = false;
            this.buttonScarica.Click += new System.EventHandler(this.buttonScarica_Click);
            // 
            // buttonCarica
            // 
            this.buttonCarica.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.buttonCarica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCarica.Location = new System.Drawing.Point(2, 2);
            this.buttonCarica.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCarica.Name = "buttonCarica";
            this.buttonCarica.Size = new System.Drawing.Size(151, 51);
            this.buttonCarica.TabIndex = 28;
            this.buttonCarica.Text = "CARICA DA FILE JSON STUDENTI";
            this.buttonCarica.UseVisualStyleBackColor = false;
            this.buttonCarica.Click += new System.EventHandler(this.buttonCarica_Click_2);
            // 
            // buttonSvuota
            // 
            this.buttonSvuota.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.buttonSvuota.FlatAppearance.BorderSize = 2;
            this.buttonSvuota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSvuota.Location = new System.Drawing.Point(28, 544);
            this.buttonSvuota.Margin = new System.Windows.Forms.Padding(2);
            this.buttonSvuota.Name = "buttonSvuota";
            this.buttonSvuota.Size = new System.Drawing.Size(107, 55);
            this.buttonSvuota.TabIndex = 26;
            this.buttonSvuota.Text = "SVUOTA CELLE";
            this.buttonSvuota.UseVisualStyleBackColor = true;
            this.buttonSvuota.Click += new System.EventHandler(this.buttonSvuota_Click);
            // 
            // labelClasse
            // 
            this.labelClasse.AutoSize = true;
            this.labelClasse.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClasse.Location = new System.Drawing.Point(54, 451);
            this.labelClasse.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelClasse.Name = "labelClasse";
            this.labelClasse.Size = new System.Drawing.Size(55, 24);
            this.labelClasse.TabIndex = 21;
            this.labelClasse.Text = "CLASSE";
            // 
            // textBoxClasse
            // 
            this.textBoxClasse.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxClasse.Location = new System.Drawing.Point(28, 487);
            this.textBoxClasse.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxClasse.Name = "textBoxClasse";
            this.textBoxClasse.Size = new System.Drawing.Size(123, 30);
            this.textBoxClasse.TabIndex = 5;
            this.textBoxClasse.Text = "4IA";
            // 
            // dataGridViewStudente
            // 
            this.dataGridViewStudente.AllowUserToAddRows = false;
            this.dataGridViewStudente.AllowUserToResizeRows = false;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewStudente.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewStudente.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewStudente.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewStudente.BackgroundColor = System.Drawing.Color.DarkBlue;
            this.dataGridViewStudente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewStudente.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewStudente.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewStudente.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewStudente.ColumnHeadersHeight = 50;
            this.dataGridViewStudente.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColonnaNome,
            this.Column2,
            this.Column4,
            this.Column3,
            this.ColonnaClasse});
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewStudente.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewStudente.EnableHeadersVisualStyles = false;
            this.dataGridViewStudente.Location = new System.Drawing.Point(228, 116);
            this.dataGridViewStudente.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewStudente.Name = "dataGridViewStudente";
            this.dataGridViewStudente.ReadOnly = true;
            this.dataGridViewStudente.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewStudente.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewStudente.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToFirstHeader;
            this.dataGridViewStudente.RowTemplate.Height = 50;
            this.dataGridViewStudente.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dataGridViewStudente.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStudente.Size = new System.Drawing.Size(637, 526);
            this.dataGridViewStudente.TabIndex = 17;
            // 
            // ColonnaNome
            // 
            this.ColonnaNome.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.ColonnaNome.HeaderText = "      NOME                                        ";
            this.ColonnaNome.MinimumWidth = 10;
            this.ColonnaNome.Name = "ColonnaNome";
            this.ColonnaNome.ReadOnly = true;
            this.ColonnaNome.Width = 119;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column2.HeaderText = "        COGNOME                                              ";
            this.Column2.MinimumWidth = 10;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 130;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column4.HeaderText = "           ETA               ";
            this.Column4.MinimumWidth = 10;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 86;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column3.HeaderText = "          MATERIA PREFERITA                                     ";
            this.Column3.MinimumWidth = 10;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 158;
            // 
            // ColonnaClasse
            // 
            this.ColonnaClasse.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.ColonnaClasse.HeaderText = "            CLASSE                               ";
            this.ColonnaClasse.MinimumWidth = 10;
            this.ColonnaClasse.Name = "ColonnaClasse";
            this.ColonnaClasse.ReadOnly = true;
            this.ColonnaClasse.Width = 119;
            // 
            // textBoxCog
            // 
            this.textBoxCog.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCog.Location = new System.Drawing.Point(31, 234);
            this.textBoxCog.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxCog.Name = "textBoxCog";
            this.textBoxCog.Size = new System.Drawing.Size(120, 30);
            this.textBoxCog.TabIndex = 2;
            this.textBoxCog.Text = "Ait Taleb Nasseur";
            // 
            // textBoxPref
            // 
            this.textBoxPref.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPref.Location = new System.Drawing.Point(28, 406);
            this.textBoxPref.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPref.Name = "textBoxPref";
            this.textBoxPref.Size = new System.Drawing.Size(123, 30);
            this.textBoxPref.TabIndex = 4;
            this.textBoxPref.Text = "Informtica";
            // 
            // textBoxEta
            // 
            this.textBoxEta.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEta.Location = new System.Drawing.Point(31, 320);
            this.textBoxEta.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEta.Name = "textBoxEta";
            this.textBoxEta.Size = new System.Drawing.Size(120, 30);
            this.textBoxEta.TabIndex = 3;
            this.textBoxEta.Text = "17";
            this.textBoxEta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxEta_KeyPress);
            // 
            // textBoxNome
            // 
            this.textBoxNome.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNome.Location = new System.Drawing.Point(31, 155);
            this.textBoxNome.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(120, 30);
            this.textBoxNome.TabIndex = 1;
            this.textBoxNome.Text = "Mourad";
            // 
            // ButtonEliminaRow
            // 
            this.ButtonEliminaRow.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.ButtonEliminaRow.FlatAppearance.BorderSize = 2;
            this.ButtonEliminaRow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonEliminaRow.Location = new System.Drawing.Point(476, 15);
            this.ButtonEliminaRow.Margin = new System.Windows.Forms.Padding(2);
            this.ButtonEliminaRow.Name = "ButtonEliminaRow";
            this.ButtonEliminaRow.Size = new System.Drawing.Size(186, 51);
            this.ButtonEliminaRow.TabIndex = 18;
            this.ButtonEliminaRow.Text = "ELIMINA RIGA";
            this.ButtonEliminaRow.UseVisualStyleBackColor = true;
            this.ButtonEliminaRow.Click += new System.EventHandler(this.ButtonEliminaRow_Click_1);
            // 
            // labelCognome
            // 
            this.labelCognome.AutoSize = true;
            this.labelCognome.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCognome.Location = new System.Drawing.Point(54, 197);
            this.labelCognome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCognome.Name = "labelCognome";
            this.labelCognome.Size = new System.Drawing.Size(66, 24);
            this.labelCognome.TabIndex = 16;
            this.labelCognome.Text = "COGNOME";
            // 
            // ButtonAggiorna
            // 
            this.ButtonAggiorna.BackColor = System.Drawing.Color.DarkBlue;
            this.ButtonAggiorna.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.ButtonAggiorna.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonAggiorna.ForeColor = System.Drawing.Color.White;
            this.ButtonAggiorna.Location = new System.Drawing.Point(680, 15);
            this.ButtonAggiorna.Margin = new System.Windows.Forms.Padding(2);
            this.ButtonAggiorna.Name = "ButtonAggiorna";
            this.ButtonAggiorna.Size = new System.Drawing.Size(185, 51);
            this.ButtonAggiorna.TabIndex = 14;
            this.ButtonAggiorna.Text = "AGGIUNGI";
            this.ButtonAggiorna.UseVisualStyleBackColor = false;
            this.ButtonAggiorna.Click += new System.EventHandler(this.ButtonAggiorna_Click);
            // 
            // labelMateriaPref
            // 
            this.labelMateriaPref.AutoSize = true;
            this.labelMateriaPref.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMateriaPref.Location = new System.Drawing.Point(24, 368);
            this.labelMateriaPref.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMateriaPref.Name = "labelMateriaPref";
            this.labelMateriaPref.Size = new System.Drawing.Size(127, 24);
            this.labelMateriaPref.TabIndex = 13;
            this.labelMateriaPref.Text = "MATERIA PREFERITA";
            // 
            // labelEta
            // 
            this.labelEta.AutoSize = true;
            this.labelEta.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEta.Location = new System.Drawing.Point(60, 281);
            this.labelEta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelEta.Name = "labelEta";
            this.labelEta.Size = new System.Drawing.Size(32, 24);
            this.labelEta.TabIndex = 12;
            this.labelEta.Text = "ETA";
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNome.Location = new System.Drawing.Point(67, 119);
            this.labelNome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(42, 24);
            this.labelNome.TabIndex = 11;
            this.labelNome.Text = "NOME";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage0);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(2, 40);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1285, 676);
            this.tabControl1.TabIndex = 7;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // buttonModifica
            // 
            this.buttonModifica.BackColor = System.Drawing.Color.DarkBlue;
            this.buttonModifica.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.buttonModifica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonModifica.ForeColor = System.Drawing.Color.White;
            this.buttonModifica.Location = new System.Drawing.Point(1002, 548);
            this.buttonModifica.Margin = new System.Windows.Forms.Padding(2);
            this.buttonModifica.Name = "buttonModifica";
            this.buttonModifica.Size = new System.Drawing.Size(185, 51);
            this.buttonModifica.TabIndex = 66;
            this.buttonModifica.Text = "MODIFICA";
            this.buttonModifica.UseVisualStyleBackColor = false;
            this.buttonModifica.Click += new System.EventHandler(this.buttonModifica_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(931, 592);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 17);
            this.label10.TabIndex = 67;
            this.label10.Text = "NON FUNZIONANTE";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1283, 763);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "REGISTRO ELETTRONICO";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAssenze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPagella)).EndInit();
            this.tabPage0.ResumeLayout(false);
            this.tabPage0.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudente)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ColorDialog colorDialog2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelTitolo;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label LabelSocial;
        private System.Windows.Forms.Button Instagram;
        private System.Windows.Forms.Button Facebook;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label labelLingua;
        private System.Windows.Forms.RadioButton radioButtonEng;
        private System.Windows.Forms.RadioButton radioButtonIta;
        private System.Windows.Forms.Button ButtonImagineSf;
        private System.Windows.Forms.Label labeltitolo5;
        private System.Windows.Forms.Button ButtonCambSfo;
        private System.Windows.Forms.Button ButtonColButt;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label labelMotivazione;
        private System.Windows.Forms.Label labelData;
        private System.Windows.Forms.TextBox textBoxMotivazione;
        private System.Windows.Forms.DataGridView dataGridViewAssenze;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button ButtonAssenze;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label labelTitolo3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label labelInformazioni;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dataGridViewPagella;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Label labelMediaGen;
        private System.Windows.Forms.Button buttonAggVoti2;
        private System.Windows.Forms.Label labelTele;
        private System.Windows.Forms.Label labelTps;
        private System.Windows.Forms.Label labelSto;
        private System.Windows.Forms.Label labelSist;
        private System.Windows.Forms.Label labelMot;
        private System.Windows.Forms.Label labelIng;
        private System.Windows.Forms.Label labelIta;
        private System.Windows.Forms.Label labelMate;
        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.ComboBox comboBoxTel;
        private System.Windows.Forms.ComboBox comboBoxTps;
        private System.Windows.Forms.ComboBox comboBoxSto;
        private System.Windows.Forms.ComboBox comboBoxSist;
        private System.Windows.Forms.ComboBox comboBoxMot;
        private System.Windows.Forms.ComboBox comboBoxIng;
        private System.Windows.Forms.ComboBox comboBoxIta;
        private System.Windows.Forms.ComboBox comboBoxMate;
        private System.Windows.Forms.ComboBox comboBoxInfo;
        private System.Windows.Forms.Label labelTitolo2;
        private System.Windows.Forms.TabPage tabPage0;
        private System.Windows.Forms.Button buttonScarica;
        private System.Windows.Forms.Button buttonCarica;
        private System.Windows.Forms.Button buttonSvuota;
        private System.Windows.Forms.Label labelClasse;
        private System.Windows.Forms.TextBox textBoxClasse;
        private System.Windows.Forms.DataGridView dataGridViewStudente;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColonnaNome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColonnaClasse;
        private System.Windows.Forms.TextBox textBoxCog;
        private System.Windows.Forms.TextBox textBoxPref;
        private System.Windows.Forms.TextBox textBoxEta;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.Button ButtonEliminaRow;
        private System.Windows.Forms.Label labelCognome;
        private System.Windows.Forms.Button ButtonAggiorna;
        private System.Windows.Forms.Label labelMateriaPref;
        private System.Windows.Forms.Label labelEta;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ComboBox comboBoxElimina;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.Button buttonSalvaVoti;
        private System.Windows.Forms.Button buttonCaricaVoti;
        private System.Windows.Forms.Button buttonSalvaAssenze;
        private System.Windows.Forms.Button buttonCaricaAssenze;
        private System.Windows.Forms.Button buttonEliminaRigaAss;
        private System.Windows.Forms.Button buttonElimina;
        private System.Windows.Forms.ComboBox comboBoxModifica;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxClasseM;
        private System.Windows.Forms.TextBox textBoxCognomeM;
        private System.Windows.Forms.TextBox textBoxMateriaPrM;
        private System.Windows.Forms.TextBox textBoxEtaM;
        private System.Windows.Forms.TextBox textBoxNomeM;
        private System.Windows.Forms.Button buttonModifica;
        private System.Windows.Forms.Label label10;
    }
}

